import { useState, useEffect } from "react";
import { getShopItems, purchaseShopItem } from "@/services/api/shopService";

export const useShop = () => {
  const [items, setItems] = useState([]);
  const [gems, setGems] = useState(85);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadItems = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getShopItems();
      setItems(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const purchaseItem = async (itemId) => {
    try {
      const result = await purchaseShopItem(itemId);
      setGems(prev => prev - result.price);
      return result;
    } catch (err) {
      throw new Error(err.message);
    }
  };

  useEffect(() => {
    loadItems();
  }, []);

  return { items, gems, loading, error, purchaseItem, refetch: loadItems };
};