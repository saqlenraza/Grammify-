import { useState, useEffect } from "react";
import { getExercisesBySkillId, getAllExercises } from "@/services/api/exercisesService";

export const useExercises = (skillId = null) => {
  const [exercises, setExercises] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadExercises = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = skillId 
        ? await getExercisesBySkillId(parseInt(skillId))
        : await getAllExercises();
      setExercises(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExercises();
  }, [skillId]);

  return { exercises, loading, error, refetch: loadExercises };
};