import { useState, useEffect } from 'react';
import { getBadges, checkUnlocks, unlockBadge } from '@/services/api/badgeService';
import { useProgress } from '@/hooks/useProgress';
import { toast } from 'react-toastify';

export const useBadges = () => {
  const [badges, setBadges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { progress, stats } = useProgress();

  const loadBadges = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getBadges();
      setBadges(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const checkForUnlocks = async () => {
    try {
      const unlocks = await checkUnlocks(progress, stats);
      if (unlocks.length > 0) {
        for (const unlock of unlocks) {
          await unlockBadge(unlock.Id);
          setBadges(prev => prev.map(badge => 
            badge.Id === unlock.Id 
              ? { ...badge, unlocked: true, unlockedAt: new Date().toISOString() }
              : badge
          ));
          
          toast.success(
            `🎉 नया बैज अनलॉक हुआ: ${unlock.name}!`,
            { 
              position: "top-center",
              autoClose: 4000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
            }
          );
        }
      }
    } catch (err) {
      console.error('Error checking for unlocks:', err);
    }
  };

  useEffect(() => {
    loadBadges();
  }, []);

  useEffect(() => {
    if (progress.length > 0 && stats.totalXP > 0) {
      checkForUnlocks();
    }
  }, [progress, stats]);

  return { 
    badges, 
    loading, 
    error, 
    refetch: loadBadges,
    checkForUnlocks
  };
};