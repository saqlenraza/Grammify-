import { useState, useEffect } from "react";
import { getProgressData, checkBadgeUnlocks } from "@/services/api/progressService";

export const useProgress = () => {
  const [progress, setProgress] = useState([]);
  const [stats, setStats] = useState({
    totalXP: 0,
    totalGems: 0,
    currentStreak: 0,
    totalCrowns: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [badgeUnlocks, setBadgeUnlocks] = useState([]);
  const [unlockedLevels, setUnlockedLevels] = useState([]);

const loadProgress = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getProgressData();
      setProgress(data.progress);
      setStats(data.stats);
// Set unlocked levels from data - respects localStorage setting
      const allLevelsUnlocked = data.stats.levelUnlocks?.allLevelsUnlocked || false;
      setUnlockedLevels(allLevelsUnlocked ? ["beginner", "intermediate", "advanced"] : data.stats.levelUnlocks?.unlockedLevels || []);
      // Check for badge unlocks when progress is loaded
      const unlocks = await checkBadgeUnlocks(data.progress, data.stats);
      setBadgeUnlocks(unlocks);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const updateProgress = async (skillId, correctAnswers, totalAttempts) => {
    try {
      // Update local progress immediately for responsive UI
      setProgress(prev => prev.map(p => 
        p.skillId === skillId 
          ? { 
              ...p, 
              correctAnswers: correctAnswers,
              totalAttempts: totalAttempts,
              accuracy: Math.round((correctAnswers / totalAttempts) * 100),
              lastPracticed: new Date().toISOString().split('T')[0]
            }
          : p
      ));
      
      // Check for new badge unlocks after progress update
      const data = await getProgressData();
      const unlocks = await checkBadgeUnlocks(data.progress, data.stats);
      setBadgeUnlocks(unlocks);
      
      return { success: true };
    } catch (err) {
      setError(err.message);
      return { success: false, error: err.message };
    }
  };

  useEffect(() => {
    loadProgress();
  }, []);

return { 
    progress, 
    stats, 
    loading, 
    error, 
    badgeUnlocks,
    unlockedLevels,
    refetch: loadProgress,
    updateProgress 
  };
};