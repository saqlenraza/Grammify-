import { useState, useEffect } from "react";
import { getLessonBySkillId } from "@/services/api/lessonsService";

export const useLesson = (skillId) => {
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadLesson = async () => {
    if (!skillId) return;
    
    try {
      setLoading(true);
      setError(null);
      const data = await getLessonBySkillId(parseInt(skillId));
      setLesson(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLesson();
  }, [skillId]);

  return { lesson, loading, error, refetch: loadLesson };
};