import { useState, useEffect } from "react";

export const useUser = () => {
  const [user, setUser] = useState(null);
  const [streak, setStreak] = useState(0);
  const [xp, setXp] = useState(0);
  const [gems, setGems] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUserData = () => {
      // Simulate loading from localStorage or API
      const userData = {
        name: "राहुल",
        email: "user@example.com",
        level: localStorage.getItem("userLevel") || "beginner"
      };
      
      setUser(userData);
      setStreak(5);
      setXp(1250);
      setGems(85);
      setLoading(false);
    };

    const timer = setTimeout(loadUserData, 300);
    return () => clearTimeout(timer);
  }, []);

  return { user, streak, xp, gems, loading };
};