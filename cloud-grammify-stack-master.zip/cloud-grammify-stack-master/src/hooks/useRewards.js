import { useState, useEffect } from "react";
import { getRewards } from "@/services/api/rewardsService";

export const useRewards = () => {
  const [rewards, setRewards] = useState([]);
  const [streak, setStreak] = useState(5);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadRewards = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getRewards();
      setRewards(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const claimReward = async (rewardId) => {
    // Simulate claiming reward
    setRewards(prev => prev.filter(r => r.Id !== rewardId));
  };

  useEffect(() => {
    loadRewards();
  }, []);

  return { rewards, streak, loading, error, claimReward, refetch: loadRewards };
};