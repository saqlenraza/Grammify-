import { useState, useEffect } from "react";
import { getSkillById } from "@/services/api/skillsService";

export const useSkill = (skillId) => {
  const [skill, setSkill] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadSkill = async () => {
    if (!skillId) return;
    
    try {
      setLoading(true);
      setError(null);
      const data = await getSkillById(parseInt(skillId));
      setSkill(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSkill();
  }, [skillId]);

  return { skill, loading, error, refetch: loadSkill };
};