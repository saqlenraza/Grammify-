import { Routes, Route } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import { motion } from "framer-motion";
import WelcomePage from "@/components/pages/WelcomePage";
import LevelSelectionPage from "@/components/pages/LevelSelectionPage";
import HomePage from "@/components/pages/HomePage";
import LessonPage from "@/components/pages/LessonPage";
import PracticePage from "@/components/pages/PracticePage";
import ChallengePage from "@/components/pages/ChallengePage";
import ProgressPage from "@/components/pages/ProgressPage";
import ShopPage from "@/components/pages/ShopPage";
import SettingsPage from "@/components/pages/SettingsPage";
import RewardPage from "@/components/pages/RewardPage";
import AchievementBadges from "@/components/pages/AchievementBadges";
import Layout from "@/components/organisms/Layout";

const App = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-success-50 to-accent-50">
      <Routes>
        <Route path="/" element={<WelcomePage />} />
        <Route path="/level-selection" element={<LevelSelectionPage />} />
        <Route path="/home" element={<Layout><HomePage /></Layout>} />
        <Route path="/lesson/:skillId" element={<Layout><LessonPage /></Layout>} />
        <Route path="/practice/:skillId" element={<Layout><PracticePage /></Layout>} />
        <Route path="/challenge" element={<Layout><ChallengePage /></Layout>} />
        <Route path="/progress" element={<Layout><ProgressPage /></Layout>} />
        <Route path="/shop" element={<Layout><ShopPage /></Layout>} />
        <Route path="/settings" element={<Layout><SettingsPage /></Layout>} />
        <Route path="/reward" element={<Layout><RewardPage /></Layout>} />
        <Route path="/achievements" element={<Layout><AchievementBadges /></Layout>} />
      </Routes>
      
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="colored"
        style={{ zIndex: 9999 }}
      />
    </div>
  );
};

export default App;