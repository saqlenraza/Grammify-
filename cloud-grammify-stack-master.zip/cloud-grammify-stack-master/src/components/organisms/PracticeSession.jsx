import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import QuestionCard from "@/components/molecules/QuestionCard";
import ProgressBar from "@/components/atoms/ProgressBar";
import Button from "@/components/atoms/Button";
import ApperIcon from "@/components/ApperIcon";
import { useExercises } from "@/hooks/useExercises";

const PracticeSession = ({ skillId, onComplete }) => {
  const { exercises, loading } = useExercises(skillId);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState([]);

  const currentQuestion = exercises[currentIndex];
  const progress = exercises.length > 0 ? ((currentIndex + 1) / exercises.length) * 100 : 0;

  const handleAnswer = (answer) => {
    const isCorrect = answer === currentQuestion.correctAnswer;
    const newAnswers = [...answers, { questionId: currentQuestion.Id, answer, isCorrect }];
    setAnswers(newAnswers);

    if (isCorrect) {
      setScore(score + 1);
      toast.success("सही जवाब! 🎉");
    } else {
      toast.error("गलत जवाब! 😅");
    }

    if (currentIndex < exercises.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // Session complete
      setTimeout(() => {
        onComplete({
          score,
          total: exercises.length,
          percentage: (score / exercises.length) * 100,
          answers: newAnswers
        });
      }, 1000);
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-4 bg-gray-200 rounded-full" />
        <div className="bg-gray-200 rounded-2xl h-64" />
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-12 bg-gray-200 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className="text-center py-12">
        <ApperIcon name="BookOpen" size={48} className="text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-600">कोई प्रश्न उपलब्ध नहीं</h3>
        <p className="text-gray-500 mt-2">कृपया बाद में दोबारा कोशिश करें</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <ApperIcon name="BookOpen" size={20} className="text-primary-600" />
          <span className="text-sm font-medium text-gray-600">
            प्रश्न {currentIndex + 1} का {exercises.length}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <ApperIcon name="Target" size={20} className="text-success" />
          <span className="text-sm font-medium text-gray-600">
            स्कोर: {score}/{exercises.length}
          </span>
        </div>
      </div>

      <ProgressBar progress={progress} variant="primary" showPercentage />

      <motion.div
        key={currentQuestion.Id}
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -50 }}
        transition={{ duration: 0.3 }}
      >
        <QuestionCard
          question={currentQuestion}
          onAnswer={handleAnswer}
          showHint={true}
        />
      </motion.div>
    </div>
  );
};

export default PracticeSession;