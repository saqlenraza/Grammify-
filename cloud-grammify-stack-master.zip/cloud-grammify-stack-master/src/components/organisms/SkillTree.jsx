import { motion } from "framer-motion";
import SkillNode from "@/components/molecules/SkillNode";
import { useSkills } from "@/hooks/useSkills";

const SkillTree = ({ onSkillSelect }) => {
  const { skills, loading } = useSkills();

if (loading) {
    return (
      <div className="space-y-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-gradient-to-r from-success-100 to-accent-100 rounded-3xl h-28 animate-pulse shadow-lg" />
        ))}
      </div>
    );
  }

return (
    <div className="space-y-6">
      {skills.map((skill, index) => (
        <motion.div
          key={skill.Id}
          initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <SkillNode
            skill={skill}
            onClick={() => onSkillSelect(skill)}
            isLocked={!skill.isUnlocked}
          />
        </motion.div>
      ))}
    </div>
  );
};

export default SkillTree;