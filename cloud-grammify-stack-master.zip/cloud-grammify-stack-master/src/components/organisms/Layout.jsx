import StatusBar from "@/components/molecules/StatusBar";
import BottomNav from "@/components/molecules/BottomNav";
import { useUser } from "@/hooks/useUser";

const Layout = ({ children }) => {
  const { user, streak, xp, gems } = useUser();

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background via-primary-50 to-secondary-50">
      <StatusBar
        user={user}
        streak={streak}
        xp={xp}
        gems={gems}
        onProfileClick={() => {}}
      />
      
      <main className="flex-1 pb-16 overflow-y-auto">
        {children}
      </main>
      
      <BottomNav />
    </div>
  );
};

export default Layout;