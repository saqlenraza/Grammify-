import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import QuestionCard from "@/components/molecules/QuestionCard";
import ProgressBar from "@/components/atoms/ProgressBar";
import Button from "@/components/atoms/Button";
import ApperIcon from "@/components/ApperIcon";
import { useExercises } from "@/hooks/useExercises";

const ChallengeMode = ({ onComplete, timeLimit = 600 }) => {
  const { exercises, loading } = useExercises();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(timeLimit);
  const [isActive, setIsActive] = useState(false);
  const [answers, setAnswers] = useState([]);

  const currentQuestion = exercises[currentIndex];
  const progress = exercises.length > 0 ? ((currentIndex + 1) / exercises.length) * 100 : 0;

  useEffect(() => {
    let interval = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handleTimeUp();
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const handleStart = () => {
    setIsActive(true);
    toast.info("चुनौती शुरू! 🚀");
  };

  const handleTimeUp = () => {
    setIsActive(false);
    toast.warning("समय समाप्त! ⏰");
    onComplete({
      score,
      total: exercises.length,
      percentage: (score / exercises.length) * 100,
      answers,
      timeUp: true
    });
  };

  const handleAnswer = (answer) => {
    const isCorrect = answer === currentQuestion.correctAnswer;
    const newAnswers = [...answers, { questionId: currentQuestion.Id, answer, isCorrect }];
    setAnswers(newAnswers);

    if (isCorrect) {
      setScore(score + 1);
    }

    if (currentIndex < exercises.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // Challenge complete
      setIsActive(false);
      onComplete({
        score: score + (isCorrect ? 1 : 0),
        total: exercises.length,
        percentage: ((score + (isCorrect ? 1 : 0)) / exercises.length) * 100,
        answers: newAnswers,
        timeUp: false
      });
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-6">
        <div className="h-4 bg-gray-200 rounded-full" />
        <div className="bg-gray-200 rounded-2xl h-64" />
      </div>
    );
  }

  if (!isActive && timeLeft === timeLimit) {
    return (
      <div className="text-center py-12 space-y-6">
        <div className="w-24 h-24 mx-auto bg-gradient-to-r from-error to-warning rounded-full flex items-center justify-center">
          <ApperIcon name="Target" size={48} className="text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">चुनौती मोड</h2>
          <p className="text-gray-600">समय सीमा: {formatTime(timeLimit)}</p>
          <p className="text-sm text-gray-500 mt-2">कुल प्रश्न: {exercises.length}</p>
        </div>
        <Button onClick={handleStart} variant="primary" size="lg" className="px-8">
          <ApperIcon name="Play" size={20} className="mr-2" />
          चुनौती शुरू करें
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-error to-warning rounded-xl text-white">
        <div className="flex items-center space-x-2">
          <ApperIcon name="Clock" size={20} />
          <span className="font-bold text-lg">{formatTime(timeLeft)}</span>
        </div>
        <div className="flex items-center space-x-2">
          <ApperIcon name="Target" size={20} />
          <span className="font-bold">
            {currentIndex + 1}/{exercises.length}
          </span>
        </div>
      </div>

      <ProgressBar progress={progress} variant="warning" />

      {currentQuestion && (
        <motion.div
          key={currentQuestion.Id}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2 }}
        >
          <QuestionCard
            question={currentQuestion}
            onAnswer={handleAnswer}
            showHint={false}
          />
        </motion.div>
      )}
    </div>
  );
};

export default ChallengeMode;