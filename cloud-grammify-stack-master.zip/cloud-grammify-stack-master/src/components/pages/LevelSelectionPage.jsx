import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import LevelCard from "@/components/molecules/LevelCard";
import Button from "@/components/atoms/Button";
import ApperIcon from "@/components/ApperIcon";

const LevelSelectionPage = () => {
  const navigate = useNavigate();
  const [selectedLevel, setSelectedLevel] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

const levels = ["beginner", "intermediate", "advanced"];

  const handleLevelSelect = (level) => {
    setSelectedLevel(level);
  };

  const handleContinue = () => {
    if (!selectedLevel) {
      toast.warning("कृपया एक स्तर चुनें");
      return;
    }

    setIsLoading(true);
    // Save preferred level to localStorage (all levels are unlocked)
    localStorage.setItem("userLevel", selectedLevel);
    localStorage.setItem("allLevelsUnlocked", "true");
    
    setTimeout(() => {
      toast.success(`${selectedLevel} स्तर चुना गया! सभी स्तर अनलॉक हैं! 🎉`);
      navigate("/home");
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary-50 to-secondary-50 p-4">
      <div className="max-w-md mx-auto py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
<h1 className="text-2xl font-bold text-gray-800 mb-2">अपना स्तर चुनें</h1>
          <p className="text-gray-600">सभी स्तर अनलॉक हैं - अपना पसंदीदा चुनें</p>
        </motion.div>

        <div className="space-y-4 mb-8">
          {levels.map((level, index) => (
            <motion.div
              key={level}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <LevelCard
                level={level}
                isSelected={selectedLevel === level}
                onClick={() => handleLevelSelect(level)}
              />
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="space-y-4"
        >
          <Button
            onClick={handleContinue}
            disabled={isLoading || !selectedLevel}
            variant="primary"
            size="lg"
            className="w-full"
          >
            {isLoading ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="mr-2"
                >
                  <ApperIcon name="Loader" size={20} />
                </motion.div>
                तैयार हो रहा है...
              </>
            ) : (
              <>
                <ApperIcon name="ArrowRight" size={20} className="mr-2" />
                जारी रखें
              </>
            )}
          </Button>

<div className="text-center">
            <p className="text-sm text-gray-500">
              सभी स्तर उपलब्ध हैं - आप कभी भी बदल सकते हैं
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LevelSelectionPage;