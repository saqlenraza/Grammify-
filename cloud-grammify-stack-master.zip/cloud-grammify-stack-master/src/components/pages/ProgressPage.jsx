import { motion } from "framer-motion";
import { useProgress } from "@/hooks/useProgress";
import Card from "@/components/atoms/Card";
import ProgressBar from "@/components/atoms/ProgressBar";
import Badge from "@/components/atoms/Badge";
import ApperIcon from "@/components/ApperIcon";
import Loading from "@/components/ui/Loading";

const ProgressPage = () => {
  const { progress, stats, loading } = useProgress();

  if (loading) {
    return <Loading text="प्रगति लोड हो रही है..." />;
  }

  return (
    <div className="p-4 pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-2xl font-bold text-gray-800 mb-2">आपकी प्रगति</h1>
        <p className="text-gray-600">अपनी उपलब्धियों को देखें</p>
      </motion.div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="p-4 text-center bg-gradient-to-br from-primary-50 to-secondary-50 border-primary-200">
          <div className="w-12 h-12 mx-auto bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center mb-3">
            <ApperIcon name="Star" size={24} className="text-white" />
          </div>
          <div className="text-2xl font-bold text-primary-600">{stats.totalXP}</div>
          <div className="text-sm text-gray-600">कुल XP</div>
        </Card>

        <Card className="p-4 text-center bg-gradient-to-br from-accent-50 to-success/10 border-accent-200">
          <div className="w-12 h-12 mx-auto bg-gradient-to-r from-accent-500 to-success rounded-full flex items-center justify-center mb-3">
            <ApperIcon name="Gem" size={24} className="text-white" />
          </div>
          <div className="text-2xl font-bold text-accent-600">{stats.totalGems}</div>
          <div className="text-sm text-gray-600">कुल जेम्स</div>
        </Card>

        <Card className="p-4 text-center bg-gradient-to-br from-warning/10 to-secondary-50 border-warning/20">
          <div className="w-12 h-12 mx-auto bg-gradient-to-r from-warning to-secondary-500 rounded-full flex items-center justify-center mb-3">
            <ApperIcon name="Flame" size={24} className="text-white" />
          </div>
          <div className="text-2xl font-bold text-warning">{stats.currentStreak}</div>
          <div className="text-sm text-gray-600">दिन स्ट्रीक</div>
        </Card>

        <Card className="p-4 text-center bg-gradient-to-br from-success/10 to-accent-50 border-success/20">
          <div className="w-12 h-12 mx-auto bg-gradient-to-r from-success to-accent-500 rounded-full flex items-center justify-center mb-3">
            <ApperIcon name="Crown" size={24} className="text-white" />
          </div>
          <div className="text-2xl font-bold text-success">{stats.totalCrowns}</div>
          <div className="text-sm text-gray-600">कुल क्राउन</div>
        </Card>
      </div>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="TrendingUp" size={20} className="mr-2 text-primary-600" />
          कौशल प्रगति
        </h3>
        
        <div className="space-y-4">
          {progress.map((skill) => (
            <motion.div
              key={skill.skillId}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                    <ApperIcon name="BookOpen" size={16} className="text-white" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-800">{skill.skillName}</div>
                    <div className="text-sm text-gray-600">{skill.accuracy}% सटीकता</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {[...Array(5)].map((_, i) => (
                    <ApperIcon
                      key={i}
                      name="Crown"
                      size={14}
                      className={i < skill.crownLevel ? "text-warning" : "text-gray-300"}
                    />
                  ))}
                </div>
              </div>
              
              <ProgressBar
                progress={skill.progress}
                variant="primary"
                size="sm"
              />
            </motion.div>
          ))}
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="AlertTriangle" size={20} className="mr-2 text-warning" />
          सुधार की जरूरत
        </h3>
        
        <div className="space-y-3">
          {progress
            .filter(skill => skill.accuracy < 80)
            .map((skill) => (
              <div key={skill.skillId} className="flex items-center justify-between p-3 bg-warning/10 rounded-lg border border-warning/20">
                <div>
                  <div className="font-medium text-gray-800">{skill.skillName}</div>
                  <div className="text-sm text-gray-600">{skill.accuracy}% सटीकता</div>
                </div>
                <Badge variant="warning">अभ्यास करें</Badge>
              </div>
            ))}
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="Calendar" size={20} className="mr-2 text-accent-500" />
          साप्ताहिक लक्ष्य
        </h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-gray-700">दैनिक अभ्यास</span>
            <span className="text-sm font-medium text-success">5/7 दिन</span>
          </div>
          <ProgressBar progress={71} variant="success" size="sm" />
          
          <div className="flex items-center justify-between">
            <span className="text-gray-700">XP लक्ष्य</span>
            <span className="text-sm font-medium text-primary-600">350/500</span>
          </div>
          <ProgressBar progress={70} variant="primary" size="sm" />
        </div>
      </Card>
    </div>
  );
};

export default ProgressPage;