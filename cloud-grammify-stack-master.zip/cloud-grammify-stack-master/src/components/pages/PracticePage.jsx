import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import PracticeSession from "@/components/organisms/PracticeSession";
import Button from "@/components/atoms/Button";
import Card from "@/components/atoms/Card";
import ApperIcon from "@/components/ApperIcon";

const PracticePage = () => {
  const { skillId } = useParams();
  const navigate = useNavigate();
  const [sessionComplete, setSessionComplete] = useState(false);
  const [results, setResults] = useState(null);

  const handleSessionComplete = (sessionResults) => {
    setResults(sessionResults);
    setSessionComplete(true);
    
    // Award XP and gems
    const xpEarned = sessionResults.score * 10;
    const gemsEarned = sessionResults.score * 2;
    
    toast.success(`अभ्यास पूरा! +${xpEarned} XP, +${gemsEarned} 💎`);
  };

  const handleContinue = () => {
    navigate("/home");
  };

  const handleRetry = () => {
    setSessionComplete(false);
    setResults(null);
  };

  if (sessionComplete && results) {
    return (
      <div className="p-4 pb-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-6"
        >
          <Card className="p-6 text-center space-y-4">
            <div className="w-20 h-20 mx-auto bg-gradient-to-r from-success to-accent-500 rounded-full flex items-center justify-center">
              <ApperIcon name="Trophy" size={40} className="text-white" />
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-gray-800">बधाई हो! 🎉</h2>
              <p className="text-gray-600">आपने अभ्यास पूरा किया</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-success/10 p-4 rounded-xl border border-success/20">
                <div className="text-2xl font-bold text-success">{results.score}</div>
                <div className="text-sm text-gray-600">सही जवाब</div>
              </div>
              <div className="bg-primary-50 p-4 rounded-xl border border-primary-200">
                <div className="text-2xl font-bold text-primary-600">{Math.round(results.percentage)}%</div>
                <div className="text-sm text-gray-600">स्कोर</div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-warning/10 to-secondary-500/10 p-4 rounded-xl border border-warning/20">
              <div className="flex items-center justify-center space-x-4">
                <div className="flex items-center space-x-1">
                  <ApperIcon name="Star" size={20} className="text-warning" />
                  <span className="font-bold">+{results.score * 10} XP</span>
                </div>
                <div className="flex items-center space-x-1">
                  <ApperIcon name="Gem" size={20} className="text-accent-500" />
                  <span className="font-bold">+{results.score * 2}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleContinue}
                variant="primary"
                size="lg"
                className="w-full"
              >
                <ApperIcon name="Home" size={20} className="mr-2" />
                होम पर जाएं
              </Button>
              
              <Button
                onClick={handleRetry}
                variant="secondary"
                size="lg"
                className="w-full"
              >
                <ApperIcon name="RotateCcw" size={20} className="mr-2" />
                दोबारा करें
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4 pb-6">
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          onClick={() => navigate("/home")}
          className="p-2"
        >
          <ApperIcon name="ArrowLeft" size={20} />
        </Button>
        <h1 className="text-lg font-semibold text-gray-800">अभ्यास</h1>
        <div className="w-8" />
      </div>

      <PracticeSession
        skillId={skillId}
        onComplete={handleSessionComplete}
      />
    </div>
  );
};

export default PracticePage;