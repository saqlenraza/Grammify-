import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import ChallengeMode from "@/components/organisms/ChallengeMode";
import Button from "@/components/atoms/Button";
import Card from "@/components/atoms/Card";
import ApperIcon from "@/components/ApperIcon";

const ChallengePage = () => {
  const navigate = useNavigate();
  const [challengeComplete, setChallengeComplete] = useState(false);
  const [results, setResults] = useState(null);

  const handleChallengeComplete = (challengeResults) => {
    setResults(challengeResults);
    setChallengeComplete(true);
    
    // Award bonus XP and gems for challenge
    const xpEarned = challengeResults.score * 15;
    const gemsEarned = challengeResults.score * 3;
    
    toast.success(`चुनौती पूरी! +${xpEarned} XP, +${gemsEarned} 💎`);
  };

  const handleContinue = () => {
    navigate("/home");
  };

  const handleRetry = () => {
    setChallengeComplete(false);
    setResults(null);
  };

  if (challengeComplete && results) {
    const getRankMessage = (percentage) => {
      if (percentage >= 90) return { rank: "मास्टर", message: "शानदार प्रदर्शन!", color: "text-warning" };
      if (percentage >= 75) return { rank: "एक्सपर्ट", message: "बहुत अच्छा!", color: "text-success" };
      if (percentage >= 60) return { rank: "गुड", message: "अच्छा प्रयास!", color: "text-accent-500" };
      return { rank: "बेगिनर", message: "अभ्यास जारी रखें!", color: "text-primary-600" };
    };

    const rank = getRankMessage(results.percentage);

    return (
      <div className="p-4 pb-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="space-y-6"
        >
          <Card className="p-6 text-center space-y-4">
            <div className="w-24 h-24 mx-auto bg-gradient-to-r from-error to-warning rounded-full flex items-center justify-center">
              <ApperIcon name="Award" size={48} className="text-white" />
            </div>
            
            <div>
              <h2 className="text-2xl font-bold text-gray-800">चुनौती पूरी! 🏆</h2>
              <p className="text-gray-600">
                {results.timeUp ? "समय समाप्त हो गया" : "बेहतरीन प्रदर्शन!"}
              </p>
            </div>

            <div className={`text-3xl font-bold ${rank.color}`}>
              {rank.rank}
            </div>
            <p className="text-gray-600">{rank.message}</p>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-success/10 p-4 rounded-xl border border-success/20">
                <div className="text-xl font-bold text-success">{results.score}</div>
                <div className="text-xs text-gray-600">सही</div>
              </div>
              <div className="bg-error/10 p-4 rounded-xl border border-error/20">
                <div className="text-xl font-bold text-error">{results.total - results.score}</div>
                <div className="text-xs text-gray-600">गलत</div>
              </div>
              <div className="bg-primary-50 p-4 rounded-xl border border-primary-200">
                <div className="text-xl font-bold text-primary-600">{Math.round(results.percentage)}%</div>
                <div className="text-xs text-gray-600">स्कोर</div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-warning/10 to-secondary-500/10 p-4 rounded-xl border border-warning/20">
              <div className="flex items-center justify-center space-x-4">
                <div className="flex items-center space-x-1">
                  <ApperIcon name="Star" size={20} className="text-warning" />
                  <span className="font-bold">+{results.score * 15} XP</span>
                </div>
                <div className="flex items-center space-x-1">
                  <ApperIcon name="Gem" size={20} className="text-accent-500" />
                  <span className="font-bold">+{results.score * 3}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleContinue}
                variant="primary"
                size="lg"
                className="w-full"
              >
                <ApperIcon name="Home" size={20} className="mr-2" />
                होम पर जाएं
              </Button>
              
              <Button
                onClick={handleRetry}
                variant="secondary"
                size="lg"
                className="w-full"
              >
                <ApperIcon name="RotateCcw" size={20} className="mr-2" />
                दोबारा करें
              </Button>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4 pb-6">
      <div className="flex items-center justify-between mb-6">
        <Button
          variant="ghost"
          onClick={() => navigate("/home")}
          className="p-2"
        >
          <ApperIcon name="ArrowLeft" size={20} />
        </Button>
        <h1 className="text-lg font-semibold text-gray-800">चुनौती मोड</h1>
        <div className="w-8" />
      </div>

      <ChallengeMode onComplete={handleChallengeComplete} />
    </div>
  );
};

export default ChallengePage;