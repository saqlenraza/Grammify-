import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import { useShop } from "@/hooks/useShop";
import Card from "@/components/atoms/Card";
import Button from "@/components/atoms/Button";
import ApperIcon from "@/components/ApperIcon";
import Loading from "@/components/ui/Loading";

const ShopPage = () => {
  const { items, gems, loading, purchaseItem } = useShop();
  const [purchasing, setPurchasing] = useState(null);

  const handlePurchase = async (item) => {
    if (gems < item.price) {
      toast.error("पर्याप्त जेम्स नहीं हैं!");
      return;
    }

    setPurchasing(item.Id);
    
    try {
      await purchaseItem(item.Id);
      toast.success(`${item.nameHindi} खरीदा गया! 🎉`);
    } catch (error) {
      toast.error("खरीदारी में समस्या हुई");
    } finally {
      setPurchasing(null);
    }
  };

  if (loading) {
    return <Loading text="दुकान लोड हो रही है..." />;
  }

  return (
    <div className="p-4 pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-2xl font-bold text-gray-800 mb-2">दुकान</h1>
        <p className="text-gray-600">अपने जेम्स का उपयोग करें</p>
      </motion.div>

      <Card className="p-4 bg-gradient-to-r from-accent-500 to-success text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
              <ApperIcon name="Gem" size={24} className="text-white" />
            </div>
            <div>
              <div className="text-lg font-semibold">आपके जेम्स</div>
              <div className="text-sm opacity-90">खर्च करने के लिए तैयार</div>
            </div>
          </div>
          <div className="text-2xl font-bold">{gems}</div>
        </div>
      </Card>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800">उपलब्ध आइटम</h3>
        
        <div className="grid gap-4">
          {items.map((item) => (
            <motion.div
              key={item.Id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02 }}
            >
              <Card className="p-4 hover:shadow-premium transition-all duration-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${item.bgColor}`}>
                      <ApperIcon name={item.icon} size={24} className="text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800">{item.nameHindi}</div>
                      <div className="text-sm text-gray-600">{item.name}</div>
                      <div className="text-xs text-gray-500 mt-1">{item.description}</div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex items-center space-x-1 mb-2">
                      <ApperIcon name="Gem" size={16} className="text-accent-500" />
                      <span className="font-bold text-accent-600">{item.price}</span>
                    </div>
                    <Button
                      onClick={() => handlePurchase(item)}
                      disabled={gems < item.price || purchasing === item.Id}
                      variant={gems >= item.price ? "primary" : "secondary"}
                      size="sm"
                    >
                      {purchasing === item.Id ? (
                        <>
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                            className="mr-1"
                          >
                            <ApperIcon name="Loader" size={14} />
                          </motion.div>
                          खरीदा जा रहा है...
                        </>
                      ) : gems >= item.price ? (
                        "खरीदें"
                      ) : (
                        "जेम्स कम हैं"
                      )}
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Card className="p-6 bg-gradient-to-br from-warning/10 to-secondary-50 border-warning/20">
        <div className="text-center space-y-2">
          <ApperIcon name="Lightbulb" size={32} className="text-warning mx-auto" />
          <h3 className="font-semibold text-gray-800">जेम्स कैसे कमाएं?</h3>
          <div className="space-y-1 text-sm text-gray-600">
            <p>• रोजाना अभ्यास करें</p>
            <p>• चुनौतियों में भाग लें</p>
            <p>• पाठ पूरे करें</p>
            <p>• स्ट्रीक बनाए रखें</p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ShopPage;