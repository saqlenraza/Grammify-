import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useSkill } from "@/hooks/useSkill";
import { useLesson } from "@/hooks/useLesson";
import Button from "@/components/atoms/Button";
import Card from "@/components/atoms/Card";
import ApperIcon from "@/components/ApperIcon";
import Loading from "@/components/ui/Loading";
import Error from "@/components/ui/Error";

const LessonPage = () => {
  const { skillId } = useParams();
  const navigate = useNavigate();
  const { skill, loading: skillLoading } = useSkill(skillId);
  const { lesson, loading: lessonLoading } = useLesson(skillId);

  const loading = skillLoading || lessonLoading;

  if (loading) {
    return <Loading text="पाठ लोड हो रहा है..." />;
  }

  if (!skill || !lesson) {
    return (
      <Error 
        message="पाठ लोड नहीं हो सका" 
        onRetry={() => window.location.reload()}
      />
    );
  }

  const handleStartPractice = () => {
    navigate(`/practice/${skillId}`);
  };

  return (
    <div className="p-4 pb-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-6"
      >
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={() => navigate("/home")}
            className="p-2"
          >
            <ApperIcon name="ArrowLeft" size={20} />
          </Button>
          <h1 className="text-lg font-semibold text-gray-800">{skill.nameHindi}</h1>
          <div className="w-8" />
        </div>

        <Card className="p-6 bg-gradient-to-br from-primary-50 to-secondary-50 border-primary-200">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 mx-auto bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
              <ApperIcon name="BookOpen" size={32} className="text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">{lesson.titleHindi}</h2>
              <p className="text-gray-600">{lesson.title}</p>
            </div>
          </div>
        </Card>

        <Card className="p-6 space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center">
            <ApperIcon name="BookOpen" size={20} className="mr-2 text-primary-600" />
            पाठ की जानकारी
          </h3>
          
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-800 mb-2">मुख्य नियम:</h4>
              <div className="bg-gray-50 p-4 rounded-xl">
                <p className="text-gray-700">{lesson.content.rules}</p>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-800 mb-2">उदाहरण:</h4>
              <div className="space-y-2">
                {lesson.content.examples.map((example, index) => (
                  <div key={index} className="bg-accent-50 p-3 rounded-lg border border-accent-200">
                    <p className="text-gray-800 font-medium">{example.english}</p>
                    <p className="text-gray-600 text-sm">{example.hindi}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-800 mb-2">सामान्य गलतियाँ:</h4>
              <div className="bg-error/10 p-4 rounded-xl border border-error/20">
                <ul className="space-y-2">
                  {lesson.content.commonMistakes.map((mistake, index) => (
                    <li key={index} className="text-gray-700 flex items-start">
                      <ApperIcon name="X" size={16} className="text-error mt-1 mr-2 flex-shrink-0" />
                      <span>{mistake}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-gray-800 mb-2">याद रखने की तरकीब:</h4>
              <div className="bg-warning/10 p-4 rounded-xl border border-warning/20">
                <p className="text-gray-700">{lesson.content.memoryTrick}</p>
              </div>
            </div>
          </div>
        </Card>

        <Button
          onClick={handleStartPractice}
          variant="primary"
          size="lg"
          className="w-full"
        >
          <ApperIcon name="Play" size={20} className="mr-2" />
          अभ्यास शुरू करें
        </Button>
      </motion.div>
    </div>
  );
};

export default LessonPage;