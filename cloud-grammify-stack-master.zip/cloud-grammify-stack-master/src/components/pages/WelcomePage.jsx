import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Button from "@/components/atoms/Button";
import ApperIcon from "@/components/ApperIcon";

const WelcomePage = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleStart = () => {
    setIsLoading(true);
    setTimeout(() => {
      navigate("/level-selection");
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-500 via-secondary-500 to-accent-500 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center space-y-8 max-w-md"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 300 }}
          className="space-y-4"
        >
          <div className="w-24 h-24 mx-auto bg-white rounded-3xl flex items-center justify-center shadow-2xl">
            <ApperIcon name="BookOpen" size={48} className="text-primary-600" />
          </div>
<div>
            <h1 className="text-4xl font-bold text-white mb-2">Grammify</h1>
            <p className="text-lg text-white/90">Learn English Grammar</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="space-y-4"
        >
<div className="glass-effect p-6 rounded-2xl text-white">
            <h2 className="text-xl font-semibold mb-3">Welcome!</h2>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center space-x-2">
                <ApperIcon name="Check" size={16} className="text-success" />
                <span>Easy interactive learning</span>
              </li>
              <li className="flex items-center space-x-2">
                <ApperIcon name="Check" size={16} className="text-success" />
                <span>Fun exercises and games</span>
              </li>
              <li className="flex items-center space-x-2">
                <ApperIcon name="Check" size={16} className="text-success" />
                <span>Exam preparation</span>
              </li>
            </ul>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="space-y-4"
        >
          <Button
            onClick={handleStart}
            disabled={isLoading}
            variant="secondary"
            size="lg"
            className="w-full bg-white text-primary-600 hover:bg-gray-50 font-semibold"
          >
            {isLoading ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="mr-2"
                >
                  <ApperIcon name="Loader" size={20} />
                </motion.div>
Getting Ready...
              </>
            ) : (
              <>
                <ApperIcon name="Play" size={20} className="mr-2" />
                Get Started
              </>
            )}
          </Button>
          
          <div className="flex items-center justify-center space-x-4 text-white/70 text-sm">
            <span>🇮🇳</span>
            <span>Made for India</span>
            <span>🇮🇳</span>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default WelcomePage;