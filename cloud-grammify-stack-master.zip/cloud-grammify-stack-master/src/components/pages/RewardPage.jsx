import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useRewards } from "@/hooks/useRewards";
import { useProgress } from "@/hooks/useProgress";
import RewardChest from "@/components/molecules/RewardChest";
import Card from "@/components/atoms/Card";
import ApperIcon from "@/components/ApperIcon";
import Loading from "@/components/ui/Loading";
import { toast } from "react-toastify";

const RewardPage = () => {
  const { rewards, streak, loading, claimReward } = useRewards();
  const { stats } = useProgress();
  const [claimedRewards, setClaimedRewards] = useState(new Set());
  const [milestoneRewards, setMilestoneRewards] = useState([]);

  const milestones = [
    { days: 7, xp: 50, gems: 10 },
    { days: 14, xp: 100, gems: 25 },
    { days: 30, xp: 250, gems: 50 },
    { days: 60, xp: 500, gems: 100 },
    { days: 100, xp: 1000, gems: 200 }
  ];

  useEffect(() => {
    // Generate milestone rewards for achieved milestones
    const achievedMilestones = milestones.filter(m => 
      streak >= m.days && 
      !claimedRewards.has(`milestone-${m.days}`)
    );

    const newMilestoneRewards = achievedMilestones.map(milestone => ({
      Id: `milestone-${milestone.days}`,
      title: `${milestone.days} Day Streak Milestone`,
      titleHindi: `${milestone.days} दिन स्ट्रीक मील्स्टोन`,
      message: `Congratulations on your ${milestone.days} day streak!`,
      messageHindi: `${milestone.days} दिन की स्ट्रीक के लिए बधाई!`,
      xp: milestone.xp,
      gems: milestone.gems,
      type: "milestone",
      milestoneData: { days: milestone.days }
    }));

    setMilestoneRewards(newMilestoneRewards);
  }, [streak, claimedRewards]);

  const handleClaimReward = (reward) => {
    setClaimedRewards(prev => new Set([...prev, reward.Id]));
    claimReward(reward.Id);
    
    if (reward.type === "milestone") {
      toast.success(
        `🎉 मील्स्टोन पूरा! ${reward.xp} XP और ${reward.gems} Gems मिले!`,
        {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        }
      );
    }
  };

  if (loading) {
    return <Loading text="इनाम लोड हो रहे हैं..." />;
  }

  const allRewards = [...rewards, ...milestoneRewards];

  return (
    <div className="p-4 pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-2xl font-bold text-gray-800 mb-2">इनाम</h1>
        <p className="text-gray-600">अपने इनाम इकट्ठा करें!</p>
      </motion.div>

      <Card className="p-6 bg-gradient-to-r from-warning/10 to-secondary-50 border-warning/20">
        <div className="text-center space-y-4">
          <motion.div 
            className="w-16 h-16 mx-auto bg-gradient-to-r from-warning to-secondary-500 rounded-full flex items-center justify-center"
            animate={{ 
              scale: [1, 1.05, 1],
              boxShadow: [
                '0 0 20px rgba(255, 107, 53, 0.3)',
                '0 0 30px rgba(255, 107, 53, 0.5)',
                '0 0 20px rgba(255, 107, 53, 0.3)'
              ]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <ApperIcon name="Flame" size={32} className="text-white" />
          </motion.div>
          <div>
            <h3 className="text-xl font-bold text-gray-800">आपकी स्ट्रीक</h3>
            <motion.p 
              className="text-3xl font-bold text-warning"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 0.5 }}
            >
              {streak} दिन
            </motion.p>
            <p className="text-sm text-gray-600">लगातार सीखने के लिए बधाई!</p>
          </div>
        </div>
      </Card>

      {allRewards.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-800 flex items-center">
            <ApperIcon name="Gift" size={20} className="mr-2 text-accent-500" />
            उपलब्ध इनाम
            {milestoneRewards.length > 0 && (
              <span className="ml-2 bg-warning text-white text-xs px-2 py-1 rounded-full">
                {milestoneRewards.length} नया!
              </span>
            )}
          </h3>
          
          <div className="grid gap-4">
            {allRewards.map((reward) => (
              <motion.div
                key={reward.Id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: reward.Id * 0.1 }}
              >
                <RewardChest
                  reward={reward}
                  onOpen={handleClaimReward}
                  isMilestone={reward.type === "milestone"}
                  milestoneData={reward.milestoneData}
                />
              </motion.div>
            ))}
          </div>
        </div>
      )}

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="Calendar" size={20} className="mr-2 text-accent-500" />
          स्ट्रीक मील्स्टोन
        </h3>
        
        <div className="space-y-3">
          {milestones.map((milestone, index) => {
            const isCompleted = streak >= milestone.days;
            const isClaimed = claimedRewards.has(`milestone-${milestone.days}`);
            
            return (
              <motion.div
                key={index}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  isCompleted 
                    ? "bg-success/10 border-success/20" 
                    : "bg-gray-50 border-gray-200"
                }`}
                animate={isCompleted && !isClaimed ? {
                  boxShadow: [
                    '0 0 0 rgba(6, 214, 160, 0.3)',
                    '0 0 20px rgba(6, 214, 160, 0.5)',
                    '0 0 0 rgba(6, 214, 160, 0.3)'
                  ]
                } : {}}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <div className="flex items-center space-x-3">
                  <ApperIcon
                    name={isCompleted ? "CheckCircle" : "Circle"}
                    size={20}
                    className={isCompleted ? "text-success" : "text-gray-400"}
                  />
                  <div>
                    <div className="font-medium text-gray-800">{milestone.days} दिन स्ट्रीक</div>
                    <div className="text-sm text-gray-600">{milestone.xp} XP + {milestone.gems} Gems</div>
                  </div>
                </div>
                {isCompleted && (
                  <div className="text-success font-medium">
                    {isClaimed ? "क्लेम किया!" : "तैयार! 🎉"}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </Card>

      <Card className="p-6 bg-gradient-to-br from-accent-50 to-primary-50 border-accent-200">
        <div className="text-center space-y-3">
          <ApperIcon name="Target" size={32} className="text-accent-500 mx-auto" />
          <h3 className="font-semibold text-gray-800">अगला इनाम</h3>
          <p className="text-sm text-gray-600">
            {streak < 7 ? `${7 - streak} दिन और सीखें` : 
             streak < 14 ? `${14 - streak} दिन और सीखें` :
             streak < 30 ? `${30 - streak} दिन और सीखें` :
             streak < 60 ? `${60 - streak} दिन और सीखें` :
             streak < 100 ? `${100 - streak} दिन और सीखें` :
             "सभी मील्स्टोन पूरे हो गए! 🎉"}
          </p>
        </div>
      </Card>
    </div>
  );
};

export default RewardPage;