import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import Card from "@/components/atoms/Card";
import Button from "@/components/atoms/Button";
import ApperIcon from "@/components/ApperIcon";

const SettingsPage = () => {
  const [settings, setSettings] = useState({
    language: "hindi",
    soundEnabled: true,
    notificationsEnabled: true,
    dailyReminder: true,
    streakReminder: true
  });

  const handleToggle = (setting) => {
    setSettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
    toast.success("सेटिंग अपडेट हो गई!");
  };

  const handleLanguageChange = (language) => {
    setSettings(prev => ({
      ...prev,
      language
    }));
    toast.success(`भाषा बदल दी गई: ${language === "hindi" ? "हिंदी" : "English"}`);
  };

  const handleResetProgress = () => {
    if (window.confirm("क्या आप वाकई अपनी प्रगति रीसेट करना चाहते हैं?")) {
      toast.success("प्रगति रीसेट हो गई!");
    }
  };

  return (
    <div className="p-4 pb-6 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h1 className="text-2xl font-bold text-gray-800 mb-2">सेटिंग</h1>
        <p className="text-gray-600">अपनी प्राथमिकताएं सेट करें</p>
      </motion.div>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="Globe" size={20} className="mr-2 text-primary-600" />
          भाषा सेटिंग
        </h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-gray-700">मुख्य भाषा</span>
            <div className="flex space-x-2">
              <Button
                variant={settings.language === "hindi" ? "primary" : "secondary"}
                size="sm"
                onClick={() => handleLanguageChange("hindi")}
              >
                हिंदी
              </Button>
              <Button
                variant={settings.language === "english" ? "primary" : "secondary"}
                size="sm"
                onClick={() => handleLanguageChange("english")}
              >
                English
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="Volume2" size={20} className="mr-2 text-accent-500" />
          ऑडियो सेटिंग
        </h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <ApperIcon name="Volume2" size={18} className="text-gray-600" />
              <span className="text-gray-700">ध्वनि प्रभाव</span>
            </div>
            <motion.button
              onClick={() => handleToggle("soundEnabled")}
              className={`w-12 h-6 rounded-full flex items-center transition-all duration-200 ${
                settings.soundEnabled ? "bg-primary-500" : "bg-gray-300"
              }`}
              whileTap={{ scale: 0.95 }}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform duration-200 ${
                  settings.soundEnabled ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </motion.button>
          </div>
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="Bell" size={20} className="mr-2 text-warning" />
          सूचना सेटिंग
        </h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <ApperIcon name="Bell" size={18} className="text-gray-600" />
              <span className="text-gray-700">सूचनाएं</span>
            </div>
            <motion.button
              onClick={() => handleToggle("notificationsEnabled")}
              className={`w-12 h-6 rounded-full flex items-center transition-all duration-200 ${
                settings.notificationsEnabled ? "bg-primary-500" : "bg-gray-300"
              }`}
              whileTap={{ scale: 0.95 }}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform duration-200 ${
                  settings.notificationsEnabled ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </motion.button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <ApperIcon name="Calendar" size={18} className="text-gray-600" />
              <span className="text-gray-700">दैनिक रिमाइंडर</span>
            </div>
            <motion.button
              onClick={() => handleToggle("dailyReminder")}
              className={`w-12 h-6 rounded-full flex items-center transition-all duration-200 ${
                settings.dailyReminder ? "bg-primary-500" : "bg-gray-300"
              }`}
              whileTap={{ scale: 0.95 }}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform duration-200 ${
                  settings.dailyReminder ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </motion.button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <ApperIcon name="Flame" size={18} className="text-gray-600" />
              <span className="text-gray-700">स्ट्रीक रिमाइंडर</span>
            </div>
            <motion.button
              onClick={() => handleToggle("streakReminder")}
              className={`w-12 h-6 rounded-full flex items-center transition-all duration-200 ${
                settings.streakReminder ? "bg-primary-500" : "bg-gray-300"
              }`}
              whileTap={{ scale: 0.95 }}
            >
              <div
                className={`w-5 h-5 bg-white rounded-full shadow-md transition-transform duration-200 ${
                  settings.streakReminder ? "translate-x-6" : "translate-x-1"
                }`}
              />
            </motion.button>
          </div>
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <ApperIcon name="User" size={20} className="mr-2 text-secondary-600" />
          अकाउंट सेटिंग
        </h3>
        
        <div className="space-y-3">
          <Button
            variant="secondary"
            size="sm"
            className="w-full justify-start"
          >
            <ApperIcon name="Download" size={16} className="mr-2" />
            डेटा एक्सपोर्ट करें
          </Button>
          
          <Button
            variant="secondary"
            size="sm"
            className="w-full justify-start"
          >
            <ApperIcon name="Upload" size={16} className="mr-2" />
            डेटा इम्पोर्ट करें
          </Button>
        </div>
      </Card>

      <Card className="p-6 space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center text-error">
          <ApperIcon name="AlertTriangle" size={20} className="mr-2 text-error" />
          खतरनाक क्षेत्र
        </h3>
        
        <div className="space-y-3">
          <Button
            onClick={handleResetProgress}
            variant="danger"
            size="sm"
            className="w-full justify-start"
          >
            <ApperIcon name="RotateCcw" size={16} className="mr-2" />
            प्रगति रीसेट करें
          </Button>
          
          <p className="text-sm text-gray-500">
            चेतावनी: यह क्रिया पूर्ववत नहीं की जा सकती
          </p>
        </div>
      </Card>

      <Card className="p-6 bg-gradient-to-br from-primary-50 to-secondary-50 border-primary-200">
        <div className="text-center space-y-2">
          <ApperIcon name="Heart" size={32} className="text-primary-600 mx-auto" />
          <h3 className="font-semibold text-gray-800">Grammify</h3>
          <p className="text-sm text-gray-600">Version 1.0.0</p>
          <p className="text-xs text-gray-500">Made with ❤️ for India</p>
        </div>
      </Card>
    </div>
  );
};

export default SettingsPage;