import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "react-toastify";
import { useProgress } from "@/hooks/useProgress";
import { useBadges } from "@/hooks/useBadges";
import { cn } from "@/utils/cn";
import ApperIcon from "@/components/ApperIcon";
import Badge from "@/components/atoms/Badge";
import Button from "@/components/atoms/Button";
import Card from "@/components/atoms/Card";
import Input from "@/components/atoms/Input";
import { getBadgeProgress } from "@/services/api/badgeService";
const AchievementBadges = () => {
  const { badges, loading, error, refetch } = useBadges();
  const { progress, stats } = useProgress();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showUnlockedOnly, setShowUnlockedOnly] = useState(false);
  const [animatingBadges, setAnimatingBadges] = useState(new Set());

  const categories = [
    { id: 'all', name: 'सभी', icon: 'Grid' },
    { id: 'accuracy', name: 'सटीकता', icon: 'Target' },
    { id: 'mastery', name: 'महारत', icon: 'Crown' },
    { id: 'streak', name: 'लगातार', icon: 'Flame' },
    { id: 'special', name: 'विशेष', icon: 'Star' }
  ];

  const filteredBadges = badges?.filter(badge => {
    const matchesCategory = selectedCategory === 'all' || badge.category === selectedCategory;
    const matchesSearch = badge.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         badge.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesUnlocked = !showUnlockedOnly || badge.unlocked;
    return matchesCategory && matchesSearch && matchesUnlocked;
  }) || [];

  const handleBadgeClick = (badge) => {
    if (badge.unlocked && !animatingBadges.has(badge.Id)) {
      setAnimatingBadges(prev => new Set([...prev, badge.Id]));
      setTimeout(() => {
        setAnimatingBadges(prev => {
          const newSet = new Set(prev);
          newSet.delete(badge.Id);
          return newSet;
        });
      }, 2000);
    }
  };

  const getBadgeProgress = (badge) => {
    if (badge.unlocked) return 100;
    
    switch (badge.category) {
      case 'accuracy': {
        const avgAccuracy = progress?.reduce((sum, p) => sum + p.accuracy, 0) / (progress?.length || 1);
        return Math.min((avgAccuracy / badge.criteria.accuracy) * 100, 100);
      }
      case 'mastery': {
        const totalCrowns = stats?.totalCrowns || 0;
        return Math.min((totalCrowns / badge.criteria.crowns) * 100, 100);
      }
      case 'streak': {
        const currentStreak = stats?.currentStreak || 0;
        return Math.min((currentStreak / badge.criteria.streak) * 100, 100);
      }
      default:
        return 0;
    }
  };

  const unlockedCount = badges?.filter(b => b.unlocked).length || 0;
  const totalCount = badges?.length || 0;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <ApperIcon name="AlertCircle" size={48} className="text-error mb-4" />
        <p className="text-error text-center mb-4">{error}</p>
        <Button onClick={refetch} variant="outline">
          फिर से कोशिश करें
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary-50 to-secondary-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <ApperIcon name="Trophy" size={32} className="text-primary" />
            <h1 className="text-3xl font-display font-bold text-gray-800">
              उपलब्धि बैज
            </h1>
          </div>
          <p className="text-gray-600 mb-4">
            अपनी व्याकरण महारत के लिए बैज अर्जित करें
          </p>
          <div className="flex items-center justify-center gap-2">
            <Badge variant="success" className="text-sm">
              {unlockedCount} / {totalCount} अनलॉक
            </Badge>
            <div className="w-32 bg-gray-200 rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${(unlockedCount / totalCount) * 100}%` }}
              />
            </div>
          </div>
        </motion.div>

        {/* Controls */}
        <Card className="mb-8 p-6">
          <div className="flex flex-col lg:flex-row gap-4 items-center">
            {/* Search */}
            <div className="flex-1 relative">
              <ApperIcon name="Search" size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="बैज खोजें..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "primary" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center gap-2"
                >
                  <ApperIcon name={category.icon} size={16} />
                  {category.name}
                </Button>
              ))}
            </div>

            {/* Show Unlocked Only */}
            <Button
              variant={showUnlockedOnly ? "primary" : "outline"}
              size="sm"
              onClick={() => setShowUnlockedOnly(!showUnlockedOnly)}
              className="flex items-center gap-2"
            >
              <ApperIcon name={showUnlockedOnly ? "Eye" : "EyeOff"} size={16} />
              {showUnlockedOnly ? "सभी दिखाएं" : "अनलॉक किए गए"}
            </Button>
          </div>
        </Card>

        {/* Badge Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          <AnimatePresence>
            {filteredBadges.map((badge) => {
              const progress = getBadgeProgress(badge);
              const isAnimating = animatingBadges.has(badge.Id);
              
              return (
                <motion.div
                  key={badge.Id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.3 }}
                  className={cn(
                    "relative cursor-pointer",
                    isAnimating && "animate-pulse-glow"
                  )}
                  onClick={() => handleBadgeClick(badge)}
                >
                  <Card className={cn(
                    "relative overflow-hidden transition-all duration-300 hover:shadow-lg",
                    badge.unlocked ? "bg-gradient-to-br from-white to-primary-50 border-primary-200" : "bg-gray-50 border-gray-200",
                    isAnimating && "milestone-glow"
                  )}>
                    <div className="p-6 text-center">
                      {/* Badge Icon */}
                      <div className={cn(
                        "relative mx-auto mb-4 w-16 h-16 rounded-full flex items-center justify-center",
                        badge.unlocked ? `bg-gradient-to-br ${badge.color}` : "bg-gray-300",
                        badge.unlocked && "shadow-lg"
                      )}>
                        <ApperIcon 
                          name={badge.icon} 
                          size={32} 
                          className={badge.unlocked ? "text-white" : "text-gray-500"}
                        />
                        
                        {/* Unlock Animation */}
                        {isAnimating && (
                          <>
                            <div className="absolute inset-0 rounded-full animate-ping bg-primary opacity-75" />
                            <div className="absolute -top-2 -right-2 animate-sparkle">
                              <ApperIcon name="Sparkles" size={16} className="text-secondary" />
                            </div>
                          </>
                        )}
                        
                        {/* Lock Overlay */}
                        {!badge.unlocked && (
                          <div className="absolute inset-0 rounded-full bg-black bg-opacity-50 flex items-center justify-center">
                            <ApperIcon name="Lock" size={20} className="text-white" />
                          </div>
                        )}
                      </div>

                      {/* Badge Name */}
                      <h3 className={cn(
                        "font-display font-bold text-lg mb-2",
                        badge.unlocked ? "text-gray-800" : "text-gray-500"
                      )}>
                        {badge.name}
                      </h3>

                      {/* Badge Description */}
                      <p className={cn(
                        "text-sm mb-4",
                        badge.unlocked ? "text-gray-600" : "text-gray-400"
                      )}>
                        {badge.description}
                      </p>

                      {/* Progress Bar */}
                      {!badge.unlocked && (
                        <div className="mb-3">
                          <div className="flex justify-between text-xs text-gray-500 mb-1">
                            <span>प्रगति</span>
                            <span>{Math.round(progress)}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-primary h-2 rounded-full transition-all duration-300"
                              style={{ width: `${progress}%` }}
                            />
                          </div>
                        </div>
                      )}

                      {/* Badge Rarity */}
                      <Badge 
                        variant={badge.rarity === 'legendary' ? 'warning' : 
                               badge.rarity === 'epic' ? 'info' : 
                               badge.rarity === 'rare' ? 'success' : 'secondary'}
                        className="text-xs"
                      >
                        {badge.rarity === 'legendary' ? 'पौराणिक' :
                         badge.rarity === 'epic' ? 'महाकाव्य' :
                         badge.rarity === 'rare' ? 'दुर्लभ' : 'सामान्य'}
                      </Badge>

                      {/* Unlock Date */}
                      {badge.unlocked && badge.unlockedAt && (
                        <p className="text-xs text-gray-500 mt-2">
                          {new Date(badge.unlockedAt).toLocaleDateString('hi-IN')} को अनलॉक किया गया
                        </p>
                      )}
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Empty State */}
        {filteredBadges.length === 0 && (
          <Card className="text-center py-16">
            <ApperIcon name="Search" size={48} className="text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-display font-bold text-gray-600 mb-2">
              कोई बैज नहीं मिला
            </h3>
            <p className="text-gray-500 mb-4">
              अपने फ़िल्टर बदलने या खोज शब्द को संशोधित करने का प्रयास करें
            </p>
            <Button variant="outline" onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
              setShowUnlockedOnly(false);
            }}>
              फ़िल्टर साफ़ करें
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AchievementBadges;