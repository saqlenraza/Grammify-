import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "react-toastify";
import SkillTree from "@/components/organisms/SkillTree";
import ApperIcon from "@/components/ApperIcon";

const HomePage = () => {
  const navigate = useNavigate();

  const handleSkillSelect = (skill) => {
    if (!skill.isUnlocked) {
      toast.warning("यह कौशल अभी भी बंद है। पहले पिछले कौशल पूरे करें।");
      return;
    }
    
    navigate(`/lesson/${skill.Id}`);
  };

  return (
    <div className="p-4 pb-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">आपका पाठ्यक्रम</h1>
            <p className="text-gray-600">अपनी यात्रा जारी रखें</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/reward")}
            className="w-12 h-12 bg-gradient-to-r from-warning to-secondary-500 rounded-full flex items-center justify-center shadow-premium"
          >
            <ApperIcon name="Gift" size={24} className="text-white" />
          </motion.button>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="bg-gradient-to-br from-success/10 to-accent-500/10 p-4 rounded-xl border border-success/20 text-center"
          >
            <ApperIcon name="Target" size={24} className="text-success mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-800">आज का लक्ष्य</p>
            <p className="text-xs text-gray-600">2/3 पूरे</p>
          </motion.div>
          
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="bg-gradient-to-br from-warning/10 to-secondary-500/10 p-4 rounded-xl border border-warning/20 text-center"
          >
            <ApperIcon name="Flame" size={24} className="text-warning mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-800">स्ट्रीक</p>
            <p className="text-xs text-gray-600">5 दिन</p>
          </motion.div>
          
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="bg-gradient-to-br from-accent-500/10 to-primary-500/10 p-4 rounded-xl border border-accent-500/20 text-center"
          >
            <ApperIcon name="Crown" size={24} className="text-accent-500 mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-800">कुल क्राउन</p>
            <p className="text-xs text-gray-600">12</p>
          </motion.div>
        </div>
      </motion.div>

      <SkillTree onSkillSelect={handleSkillSelect} />
    </div>
  );
};

export default HomePage;