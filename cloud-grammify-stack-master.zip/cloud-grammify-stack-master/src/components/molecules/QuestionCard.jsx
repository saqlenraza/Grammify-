import { useState } from "react";
import { motion } from "framer-motion";
import ApperIcon from "@/components/ApperIcon";
import Card from "@/components/atoms/Card";
import Button from "@/components/atoms/Button";

const QuestionCard = ({ question, onAnswer, showHint = false }) => {
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [showFeedback, setShowFeedback] = useState(false);

  const handleAnswer = (answer) => {
    setSelectedAnswer(answer);
    setShowFeedback(true);
    setTimeout(() => {
      onAnswer(answer);
      setSelectedAnswer(null);
      setShowFeedback(false);
    }, 1500);
  };

  const isCorrect = selectedAnswer === question.correctAnswer;

  return (
    <Card className="p-6 space-y-6">
      <div className="text-center space-y-2">
        <h3 className="text-lg font-semibold text-gray-800">{question.questionHindi}</h3>
        <p className="text-sm text-gray-600">{question.question}</p>
      </div>

      <div className="space-y-3">
        {question.options.map((option, index) => (
          <motion.button
            key={index}
            onClick={() => !showFeedback && handleAnswer(option)}
            className={`w-full p-4 rounded-xl border-2 text-left transition-all duration-200 ${
              showFeedback
                ? option === question.correctAnswer
                  ? "border-success bg-success/10 text-success"
                  : option === selectedAnswer
                  ? "border-error bg-error/10 text-error"
                  : "border-gray-200 bg-gray-50 text-gray-500"
                : "border-gray-200 bg-white hover:border-primary-500 hover:bg-primary-50"
            }`}
            disabled={showFeedback}
            whileHover={!showFeedback ? { scale: 1.02 } : {}}
            whileTap={!showFeedback ? { scale: 0.98 } : {}}
          >
            <div className="flex items-center justify-between">
              <span className="font-medium">{option}</span>
              {showFeedback && option === question.correctAnswer && (
                <ApperIcon name="Check" size={20} className="text-success" />
              )}
              {showFeedback && option === selectedAnswer && option !== question.correctAnswer && (
                <ApperIcon name="X" size={20} className="text-error" />
              )}
            </div>
          </motion.button>
        ))}
      </div>

      {showFeedback && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-xl ${
            isCorrect ? "bg-success/10 border border-success/20" : "bg-error/10 border border-error/20"
          }`}
        >
          <div className="flex items-start space-x-3">
            <ApperIcon
              name={isCorrect ? "CheckCircle" : "XCircle"}
              size={20}
              className={isCorrect ? "text-success" : "text-error"}
            />
            <div>
              <p className={`font-medium ${isCorrect ? "text-success" : "text-error"}`}>
                {isCorrect ? "सही!" : "गलत!"}
              </p>
              <p className="text-sm text-gray-600 mt-1">
                {question.explanationHindi}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {showHint && !showFeedback && (
        <Button variant="ghost" size="sm" className="w-full">
          <ApperIcon name="Lightbulb" size={16} className="mr-2" />
          सुझाव लें (5 💎)
        </Button>
      )}
    </Card>
  );
};

export default QuestionCard;