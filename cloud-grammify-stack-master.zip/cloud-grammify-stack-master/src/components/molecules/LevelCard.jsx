import { motion } from "framer-motion";
import ApperIcon from "@/components/ApperIcon";
import Card from "@/components/atoms/Card";
import Badge from "@/components/atoms/Badge";

const LevelCard = ({ level, isSelected, onClick }) => {
  const levelConfig = {
    beginner: {
      icon: "Sparkles",
      titleHindi: "शुरुआती",
      titleEnglish: "Beginner",
      descriptionHindi: "पहली बार अंग्रेजी सीखने वाले",
      descriptionEnglish: "For those new to English",
      gradient: "from-green-400 to-blue-500",
      bgGradient: "from-green-50 to-blue-50"
    },
    intermediate: {
      icon: "Zap",
      titleHindi: "मध्यम",
      titleEnglish: "Intermediate",
      descriptionHindi: "कुछ बुनियादी जानकारी है",
      descriptionEnglish: "Some basic knowledge",
      gradient: "from-yellow-400 to-orange-500",
      bgGradient: "from-yellow-50 to-orange-50"
    },
    advanced: {
      icon: "Crown",
      titleHindi: "उन्नत",
      titleEnglish: "Advanced",
      descriptionHindi: "परीक्षा की तैयारी और धाराप्रवाहता",
      descriptionEnglish: "Exam prep and fluency",
      gradient: "from-purple-400 to-pink-500",
      bgGradient: "from-purple-50 to-pink-50"
    }
  };

  const config = levelConfig[level];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card
        className={`p-6 cursor-pointer transition-all duration-300 ${
          isSelected 
            ? `border-2 border-primary-500 bg-gradient-to-br ${config.bgGradient} shadow-premium` 
            : "hover:shadow-lg bg-white"
        }`}
        onClick={onClick}
        hover={!isSelected}
      >
        <div className="text-center space-y-4">
          <div className={`w-16 h-16 mx-auto rounded-full bg-gradient-to-r ${config.gradient} flex items-center justify-center`}>
            <ApperIcon name={config.icon} size={32} className="text-white" />
          </div>
          
          <div>
            <h3 className="text-xl font-bold text-gray-800">{config.titleHindi}</h3>
            <p className="text-sm text-gray-600">{config.titleEnglish}</p>
          </div>
          
          <div className="space-y-2">
            <p className="text-sm text-gray-700 font-medium">{config.descriptionHindi}</p>
            <p className="text-xs text-gray-500">{config.descriptionEnglish}</p>
          </div>

          {isSelected && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              <Badge variant="success" className="inline-flex items-center space-x-1">
                <ApperIcon name="Check" size={12} />
                <span>चयनित</span>
              </Badge>
            </motion.div>
          )}
        </div>
      </Card>
    </motion.div>
  );
};

export default LevelCard;