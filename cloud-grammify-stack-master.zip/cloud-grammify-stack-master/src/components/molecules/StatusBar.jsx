import { motion } from "framer-motion";
import ApperIcon from "@/components/ApperIcon";
import Badge from "@/components/atoms/Badge";

const StatusBar = ({ user, streak, xp, gems, onProfileClick }) => {
  return (
    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-primary-500 to-secondary-500 text-white">
      <motion.button
        onClick={onProfileClick}
        className="flex items-center space-x-2"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
          <ApperIcon name="User" size={20} />
        </div>
        <span className="font-medium">{user?.name || "उपयोगकर्ता"}</span>
      </motion.button>

      <div className="flex items-center space-x-4">
        <motion.div
          className="flex items-center space-x-1"
          whileHover={{ scale: 1.05 }}
        >
          <ApperIcon name="Flame" size={20} className="text-warning" />
          <span className="font-bold">{streak || 0}</span>
        </motion.div>

        <motion.div
          className="flex items-center space-x-1"
          whileHover={{ scale: 1.05 }}
        >
          <ApperIcon name="Star" size={20} className="text-warning" />
          <span className="font-bold">{xp || 0}</span>
        </motion.div>

        <motion.div
          className="flex items-center space-x-1"
          whileHover={{ scale: 1.05 }}
        >
          <ApperIcon name="Gem" size={20} className="text-accent-300" />
          <span className="font-bold">{gems || 0}</span>
        </motion.div>
      </div>
    </div>
  );
};

export default StatusBar;