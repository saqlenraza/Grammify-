import { motion } from "framer-motion";
import ApperIcon from "@/components/ApperIcon";
import Card from "@/components/atoms/Card";
import Badge from "@/components/atoms/Badge";

const SkillNode = ({ skill, onClick, isLocked = false }) => {
  const isCompleted = skill.lessonsCompleted === skill.totalLessons;
  const isActive = skill.lessonsCompleted > 0 && !isCompleted;
  const crownColor = skill.crownLevel >= 5 ? "text-warning" : skill.crownLevel > 0 ? "text-success-600" : "text-gray-400";
  const progressPercentage = skill.totalLessons > 0 ? (skill.lessonsCompleted / skill.totalLessons) * 100 : 0;

  const getNodeStyle = () => {
    if (isLocked) return "bg-gray-100 border-gray-200 opacity-70";
    if (isCompleted) return "bg-gradient-to-br from-success-50 to-success-100 border-success-300 shadow-success";
    if (isActive) return "bg-gradient-to-br from-warning-50 to-secondary-50 border-warning-300 shadow-warning";
    return "bg-gradient-to-br from-white to-gray-50 border-gray-200";
  };

  const getIconStyle = () => {
    if (isLocked) return "bg-gray-200 text-gray-500";
    if (isCompleted) return "bg-gradient-to-r from-success-500 to-success-600 text-white shadow-lg";
    if (isActive) return "bg-gradient-to-r from-warning-500 to-secondary-500 text-white shadow-lg";
    return "bg-gradient-to-r from-primary-500 to-secondary-500 text-white";
  };

  const getProgressBarStyle = () => {
    if (isCompleted) return "from-success-500 to-success-600";
    if (isActive) return "from-warning-500 to-secondary-500";
    return "from-primary-500 to-secondary-500";
  };
return (
    <motion.div
      className="relative mb-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={!isLocked ? { scale: 1.02 } : {}}
    >
      <Card
        className={`p-6 cursor-pointer transition-all duration-300 ${getNodeStyle()}`}
        onClick={() => !isLocked && onClick()}
        hover={!isLocked}
      >
<div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <motion.div 
              className={`w-14 h-14 rounded-full flex items-center justify-center ${getIconStyle()}`}
              whileHover={!isLocked ? { scale: 1.1 } : {}}
              whileTap={!isLocked ? { scale: 0.95 } : {}}
            >
              <ApperIcon 
                name={isLocked ? "Lock" : isCompleted ? "CheckCircle2" : isActive ? "Flame" : "Book"} 
                size={24} 
                className="text-current"
              />
            </motion.div>
<div>
              <h3 className={`font-semibold text-lg ${
                isCompleted ? "text-success-800" : isActive ? "text-warning-800" : "text-gray-800"
              }`}>
                {skill.nameHindi}
              </h3>
              <p className="text-sm text-gray-600">{skill.name}</p>
              <div className="flex items-center space-x-2 mt-2">
                <div className="w-20 h-3 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full bg-gradient-to-r ${getProgressBarStyle()} transition-all duration-700`}
                    style={{ width: `${progressPercentage}%` }}
                    initial={{ width: 0 }}
                    animate={{ width: `${progressPercentage}%` }}
                  />
                </div>
                <span className={`text-xs font-medium ${
                  isCompleted ? "text-success-600" : isActive ? "text-warning-600" : "text-gray-500"
                }`}>
                  {skill.lessonsCompleted}/{skill.totalLessons}
                </span>
              </div>
            </div>
          </div>

<div className="flex items-center space-x-1">
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: i < skill.crownLevel ? 1 : 0.7 }}
                transition={{ delay: i * 0.1 }}
              >
                <ApperIcon
                  name="Crown"
                  size={18}
                  className={i < skill.crownLevel ? crownColor : "text-gray-300"}
                />
              </motion.div>
            ))}
          </div>
        </div>

{skill.category && (
          <div className="mt-4">
            <Badge 
              variant={isCompleted ? "success" : isActive ? "progress" : "secondary"} 
              className="text-xs font-medium"
            >
              {skill.category}
            </Badge>
          </div>
        )}
      </Card>

{isLocked && (
        <div className="absolute top-4 right-4 bg-gray-500 text-white px-3 py-1 rounded-full text-xs font-medium shadow-lg">
          बंद
        </div>
      )}
      
      {isCompleted && (
        <motion.div
          className="absolute -top-2 -right-2 w-8 h-8 bg-success-500 rounded-full flex items-center justify-center shadow-lg"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
        >
          <ApperIcon name="Check" size={16} className="text-white" />
        </motion.div>
      )}
    </motion.div>
  );
};

export default SkillNode;