import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import ApperIcon from "@/components/ApperIcon";
import Card from "@/components/atoms/Card";
import Button from "@/components/atoms/Button";

const RewardChest = ({ reward, onOpen, isMilestone = false, milestoneData = null }) => {
  const [isOpening, setIsOpening] = useState(false);
  const [isOpened, setIsOpened] = useState(false);
  const [showParticles, setShowParticles] = useState(false);

  const handleOpen = () => {
    setIsOpening(true);
    if (isMilestone) {
      setShowParticles(true);
    }
    
    setTimeout(() => {
      setIsOpened(true);
      setIsOpening(false);
      onOpen(reward);
    }, isMilestone ? 1500 : 1000);
  };

  useEffect(() => {
    if (showParticles) {
      const timer = setTimeout(() => {
        setShowParticles(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showParticles]);

  const particleElements = Array.from({ length: 12 }, (_, i) => (
    <motion.div
      key={i}
      className="absolute w-2 h-2 bg-gradient-to-r from-warning to-secondary-500 rounded-full"
      style={{
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
      }}
      animate={showParticles ? {
        x: [0, (Math.random() - 0.5) * 200],
        y: [0, (Math.random() - 0.5) * 200],
        scale: [1, 0.5, 0],
        opacity: [1, 0.8, 0],
      } : {}}
      transition={{
        duration: 2,
        delay: i * 0.1,
        ease: "easeOut"
      }}
    />
  ));

  return (
    <Card className={`p-6 text-center space-y-4 ${isMilestone ? 'ring-2 ring-warning ring-opacity-50' : ''}`}>
      <motion.div
        className="relative overflow-hidden"
        animate={isOpening ? { 
          scale: isMilestone ? [1, 1.2, 1] : [1, 1.1, 1], 
          rotate: [0, 5, -5, 0] 
        } : {}}
        transition={{ duration: 0.5, repeat: isOpening ? (isMilestone ? 3 : 2) : 0 }}
      >
        <div className={`w-24 h-24 mx-auto bg-gradient-to-br from-warning to-secondary-500 rounded-2xl flex items-center justify-center ${
          isMilestone ? 'shadow-glow animate-pulse-glow' : 'shadow-glow'
        }`}>
          <ApperIcon 
            name={isOpened ? "Gift" : (isMilestone ? "Crown" : "Package")} 
            size={48} 
            className="text-white" 
          />
        </div>
        
        {isOpening && (
          <motion.div
            className={`absolute inset-0 rounded-2xl ${
              isMilestone 
                ? 'bg-gradient-to-r from-warning/70 to-secondary-500/70' 
                : 'bg-gradient-to-r from-warning/50 to-secondary-500/50'
            }`}
            animate={{ opacity: [0, 1, 0] }}
            transition={{ duration: 0.5, repeat: Infinity }}
          />
        )}

        {showParticles && particleElements}

        {isMilestone && !isOpened && (
          <motion.div
            className="absolute -inset-2 rounded-3xl border-2 border-warning"
            animate={{ 
              scale: [1, 1.1, 1],
              opacity: [0.3, 0.7, 0.3]
            }}
            transition={{ 
              duration: 1.5, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        )}
      </motion.div>

      <div>
        <h3 className="text-lg font-bold text-gray-800">
          {isMilestone && milestoneData ? `${milestoneData.days} दिन मील्स्टोन!` : reward.titleHindi}
        </h3>
        <p className="text-sm text-gray-600">
          {isMilestone && milestoneData ? `स्ट्रीक मील्स्टोन रिवॉर्ड` : reward.title}
        </p>
      </div>

      {!isOpened ? (
        <Button 
          onClick={handleOpen}
          disabled={isOpening}
          variant={isMilestone ? "primary" : "primary"}
          size="lg"
          className={`w-full ${isMilestone ? 'animate-pulse-button' : ''}`}
        >
          {isOpening ? "खुल रहा है..." : (isMilestone ? "मील्स्टोन खोलें! 🎉" : "खोलें!")}
        </Button>
      ) : (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className="space-y-3"
        >
          <div className="flex items-center justify-center space-x-4">
            <motion.div 
              className="flex items-center space-x-1"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <ApperIcon name="Star" size={20} className="text-warning" />
              <span className="font-bold">+{reward.xp} XP</span>
            </motion.div>
            <motion.div 
              className="flex items-center space-x-1"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <ApperIcon name="Gem" size={20} className="text-accent-500" />
              <span className="font-bold">+{reward.gems} Gems</span>
            </motion.div>
          </div>
          
          {isMilestone && milestoneData && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-gradient-to-r from-warning/10 to-secondary-500/10 rounded-lg p-3"
            >
              <p className="text-sm font-medium text-gray-700">🏆 मील्स्टोन पूरा!</p>
              <p className="text-xs text-gray-600">{milestoneData.days} दिन की स्ट्रीक</p>
            </motion.div>
          )}
          
          <p className="text-sm text-gray-600">{reward.messageHindi}</p>
          
          <motion.div
            className="text-2xl"
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 0.5, repeat: Infinity }}
          >
            {isMilestone ? "🎊" : "🎉"}
          </motion.div>
        </motion.div>
      )}
    </Card>
  );
};

export default RewardChest;