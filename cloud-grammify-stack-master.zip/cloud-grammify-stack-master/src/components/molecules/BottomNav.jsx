import { NavLink } from "react-router-dom";
import { motion } from "framer-motion";
import ApperIcon from "@/components/ApperIcon";

const BottomNav = () => {
  const navItems = [
    { path: "/home", icon: "Home", label: "होम", labelEn: "Home" },
    { path: "/progress", icon: "TrendingUp", label: "प्रगति", labelEn: "Progress" },
    { path: "/challenge", icon: "Target", label: "चुनौती", labelEn: "Challenge" },
    { path: "/shop", icon: "ShoppingBag", label: "दुकान", labelEn: "Shop" },
    { path: "/settings", icon: "Settings", label: "सेटिंग", labelEn: "Settings" }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
      <div className="flex justify-around items-center py-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex flex-col items-center py-2 px-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? "text-primary-600 bg-primary-50"
                  : "text-gray-600 hover:text-primary-600"
              }`
            }
          >
            {({ isActive }) => (
              <motion.div
                className="flex flex-col items-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <ApperIcon 
                  name={item.icon} 
                  size={20} 
                  className={isActive ? "text-primary-600" : "text-gray-600"}
                />
<span className="text-xs mt-1 font-medium">{item.labelEn}</span>
              </motion.div>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  );
};

export default BottomNav;