import { motion } from "framer-motion";
import ApperIcon from "@/components/ApperIcon";
import Button from "@/components/atoms/Button";

const Error = ({ message = "कुछ गलत हो गया", onRetry }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-12 space-y-4"
    >
<div className="w-16 h-16 bg-error-light/10 rounded-full flex items-center justify-center">
        <ApperIcon name="AlertCircle" size={32} className="text-error-light" />
      </div>
      <div className="text-center">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">ओह नहीं!</h3>
        <p className="text-gray-600">{message}</p>
      </div>
      {onRetry && (
        <Button onClick={onRetry} variant="primary">
          <ApperIcon name="RotateCcw" size={16} className="mr-2" />
          दोबारा कोशिश करें
        </Button>
      )}
    </motion.div>
  );
};

export default Error;