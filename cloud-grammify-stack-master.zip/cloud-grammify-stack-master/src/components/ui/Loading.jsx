import { motion } from "framer-motion";

const Loading = ({ text = "लोड हो रहा है..." }) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 space-y-4">
<motion.div
        className="w-12 h-12 border-4 border-success-200 border-t-success-600 rounded-full"
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      />
      <p className="text-gray-600 font-medium">{text}</p>
    </div>
  );
};

export default Loading;