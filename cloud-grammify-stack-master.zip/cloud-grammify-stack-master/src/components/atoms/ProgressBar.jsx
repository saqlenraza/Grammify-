import { forwardRef } from "react";
import { motion } from "framer-motion";
import { cn } from "@/utils/cn";

const ProgressBar = forwardRef(({ 
  className,
  progress = 0,
  variant = "primary",
  size = "md",
  showPercentage = false,
  ...props
}, ref) => {
  const variants = {
    primary: "from-primary-500 to-secondary-500",
    accent: "from-accent-500 to-accent-600",
    success: "from-success to-accent-500",
    warning: "from-warning to-secondary-500"
  };

  const sizes = {
    sm: "h-2",
    md: "h-3",
    lg: "h-4"
  };

  return (
    <div className="space-y-2">
      <div
        ref={ref}
        className={cn(
          "w-full bg-gray-200 rounded-full overflow-hidden",
          sizes[size],
          className
        )}
        {...props}
      >
        <motion.div
          className={cn(
            "h-full bg-gradient-to-r rounded-full",
            variants[variant]
          )}
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
      {showPercentage && (
        <div className="text-right text-sm text-gray-600">
          {Math.round(progress)}%
        </div>
      )}
    </div>
  );
});

ProgressBar.displayName = "ProgressBar";

export default ProgressBar;