import { forwardRef } from "react";
import { cn } from "@/utils/cn";

const Badge = forwardRef(({ 
  className,
  variant = "primary",
  children,
  ...props
}, ref) => {
const variants = {
    primary: "bg-gradient-to-r from-primary-500 to-secondary-500 text-white",
    secondary: "bg-success-50 text-success-800 border border-success-200",
    accent: "bg-gradient-to-r from-accent-500 to-accent-600 text-white",
    success: "bg-gradient-to-r from-success to-success-600 text-white shadow-lg",
    progress: "bg-gradient-to-r from-warning to-secondary-500 text-white shadow-lg",
    warning: "bg-gradient-to-r from-warning to-secondary-500 text-white",
    error: "bg-gradient-to-r from-error-light to-error text-white"
  };

  return (
    <span
      ref={ref}
      className={cn(
        "inline-flex items-center px-3 py-1 rounded-full text-xs font-medium shadow-sm",
        variants[variant],
        className
      )}
      {...props}
    >
      {children}
    </span>
  );
});

Badge.displayName = "Badge";

export default Badge;