import { forwardRef } from "react";
import { motion } from "framer-motion";
import { cn } from "@/utils/cn";

const Card = forwardRef(({ 
  className,
  children,
  hover = false,
  ...props
}, ref) => {
  const Component = hover ? motion.div : "div";
  
  return (
    <Component
      ref={ref}
className={cn(
        "bg-white rounded-3xl shadow-xl border border-gray-50 overflow-hidden backdrop-blur-sm",
        hover && "card-hover cursor-pointer transition-all duration-300",
        className
      )}
      {...(hover && {
        whileHover: { scale: 1.02, y: -2 },
        whileTap: { scale: 0.98 }
      })}
      {...props}
    >
      {children}
    </Component>
  );
});

Card.displayName = "Card";

export default Card;