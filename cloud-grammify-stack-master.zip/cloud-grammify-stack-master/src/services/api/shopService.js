import shopData from "@/services/mockData/shop.json";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getShopItems = async () => {
  await delay(250);
  return shopData;
};

export const purchaseShopItem = async (itemId) => {
  await delay(300);
  const item = shopData.find(i => i.Id === itemId);
  if (!item) {
    throw new Error("Item not found");
  }
  
  return {
    success: true,
    itemId,
    price: item.price,
    message: `${item.nameHindi} purchased successfully!`
  };
};