import lessonsData from "@/services/mockData/lessons.json";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getLessonBySkillId = async (skillId) => {
  await delay(250);
  const lesson = lessonsData.find(l => l.skillId === skillId);
  if (!lesson) {
    throw new Error("Lesson not found");
  }
  return lesson;
};

export const getAllLessons = async () => {
  await delay(300);
  return lessonsData;
};

export const markLessonComplete = async (lessonId) => {
  await delay(200);
  return { success: true, lessonId };
};