import badgeData from '@/services/mockData/badges.json';

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getBadges = async () => {
  await delay(300);
  return [...badgeData.badges];
};

export const getBadgeById = async (id) => {
  await delay(200);
  const badge = badgeData.badges.find(b => b.Id === parseInt(id));
  return badge ? { ...badge } : null;
};

export const checkUnlocks = async (progress, stats) => {
  await delay(200);
  const badges = [...badgeData.badges];
  const unlocks = [];

  for (const badge of badges) {
    if (badge.unlocked) continue;

    let shouldUnlock = false;

    switch (badge.category) {
      case 'accuracy': {
        const avgAccuracy = progress.reduce((sum, p) => sum + p.accuracy, 0) / (progress.length || 1);
        shouldUnlock = avgAccuracy >= badge.criteria.accuracy;
        break;
      }
      case 'mastery': {
        shouldUnlock = stats.totalCrowns >= badge.criteria.crowns;
        break;
      }
      case 'streak': {
        shouldUnlock = stats.currentStreak >= badge.criteria.streak;
        break;
      }
      case 'special': {
        // Special badges have complex criteria
        if (badge.criteria.totalXP) {
          shouldUnlock = stats.totalXP >= badge.criteria.totalXP;
        }
        if (badge.criteria.perfectSessions && progress.length > 0) {
          const perfectCount = progress.filter(p => p.accuracy === 100).length;
          shouldUnlock = shouldUnlock && perfectCount >= badge.criteria.perfectSessions;
        }
        break;
      }
    }

    if (shouldUnlock) {
      unlocks.push({ ...badge });
    }
  }

  return unlocks;
};

export const unlockBadge = async (badgeId) => {
  await delay(200);
  const badge = badgeData.badges.find(b => b.Id === parseInt(badgeId));
  
  if (badge) {
    badge.unlocked = true;
    badge.unlockedAt = new Date().toISOString();
    
    return {
      success: true,
      badge: { ...badge }
    };
  }
  
  throw new Error('Badge not found');
};

export const getBadgesByCategory = async (category) => {
  await delay(200);
  const badges = badgeData.badges.filter(b => b.category === category);
  return badges.map(badge => ({ ...badge }));
};

export const getUnlockedBadges = async () => {
  await delay(200);
  const badges = badgeData.badges.filter(b => b.unlocked);
  return badges.map(badge => ({ ...badge }));
};

export const getBadgeProgress = async (badgeId, progress, stats) => {
  await delay(100);
  const badge = badgeData.badges.find(b => b.Id === parseInt(badgeId));
  
  if (!badge) return 0;
  if (badge.unlocked) return 100;

  switch (badge.category) {
    case 'accuracy': {
      const avgAccuracy = progress.reduce((sum, p) => sum + p.accuracy, 0) / (progress.length || 1);
      return Math.min((avgAccuracy / badge.criteria.accuracy) * 100, 100);
    }
    case 'mastery': {
      return Math.min((stats.totalCrowns / badge.criteria.crowns) * 100, 100);
    }
    case 'streak': {
      return Math.min((stats.currentStreak / badge.criteria.streak) * 100, 100);
    }
    case 'special': {
      if (badge.criteria.totalXP) {
        return Math.min((stats.totalXP / badge.criteria.totalXP) * 100, 100);
      }
      return 0;
    }
    default:
      return 0;
  }
};