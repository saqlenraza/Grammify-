import exercisesData from "@/services/mockData/exercises.json";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getExercisesBySkillId = async (skillId) => {
  await delay(350);
  const exercises = exercisesData.filter(e => e.skillId === skillId);
  // Shuffle exercises for variety
  return exercises.sort(() => Math.random() - 0.5);
};

export const getAllExercises = async () => {
  await delay(400);
  // Return mix of exercises from all skills for challenge mode
  const shuffled = [...exercisesData].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, 25); // Return 25 random exercises
};

export const submitExerciseAnswer = async (exerciseId, answer) => {
  await delay(100);
  const exercise = exercisesData.find(e => e.Id === exerciseId);
  if (!exercise) {
    throw new Error("Exercise not found");
  }
  
  return {
    correct: answer === exercise.correctAnswer,
    explanation: exercise.explanationHindi
  };
};