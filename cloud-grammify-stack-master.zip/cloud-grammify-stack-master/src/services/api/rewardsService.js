import rewardsData from "@/services/mockData/rewards.json";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getRewards = async () => {
  await delay(200);
  return rewardsData;
};

export const claimReward = async (rewardId) => {
  await delay(250);
  const reward = rewardsData.find(r => r.Id === rewardId);
  if (!reward) {
    throw new Error("Reward not found");
  }
  
  return {
    success: true,
    rewardId,
    xp: reward.xp,
    gems: reward.gems
  };
};