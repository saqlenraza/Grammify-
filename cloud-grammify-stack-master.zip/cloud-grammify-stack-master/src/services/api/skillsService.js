import skillsData from "@/services/mockData/skills.json";
import React from "react";
import Error from "@/components/ui/Error";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getSkills = async () => {
  await delay(300);
  
  // Check if all levels are unlocked from localStorage
  const allLevelsUnlocked = localStorage.getItem("allLevelsUnlocked") === "true";
  
  return skillsData.map(skill => ({
    ...skill,
    isUnlocked: allLevelsUnlocked ? true : skill.Id <= 3 // All unlocked if flag set, otherwise first 3
  }));
};

export const getSkillById = async (id) => {
  await delay(200);
  const skill = skillsData.find(s => s.Id === id);
  if (!skill) {
    throw new Error("Skill not found");
  }
  
  // Check if all levels are unlocked from localStorage
  const allLevelsUnlocked = localStorage.getItem("allLevelsUnlocked") === "true";
  
  return {
    ...skill,
    isUnlocked: allLevelsUnlocked ? true : skill.Id <= 3
  };
};

export const updateSkillProgress = async (id, progress) => {
  await delay(200);
  return { success: true, progress };
};