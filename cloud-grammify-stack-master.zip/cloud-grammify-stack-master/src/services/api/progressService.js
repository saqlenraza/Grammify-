import progressData from "@/services/mockData/progress.json";
import { checkUnlocks } from "@/services/api/badgeService";

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getProgressData = async () => {
  await delay(300);
  
  // Check localStorage for level unlock status and merge with data
  const allLevelsUnlocked = localStorage.getItem("allLevelsUnlocked") === "true";
  
  return {
    ...progressData,
    stats: {
      ...progressData.stats,
      levelUnlocks: {
        ...progressData.stats.levelUnlocks,
        allLevelsUnlocked: allLevelsUnlocked,
        unlockedLevels: allLevelsUnlocked ? ["beginner", "intermediate", "advanced"] : progressData.stats.levelUnlocks.unlockedLevels
      }
    }
  };
};

export const updateProgress = async (skillId, correctAnswers, totalAttempts) => {
  await delay(200);
  return {
    success: true,
    accuracy: (correctAnswers / totalAttempts) * 100
  };
};

export const getMilestoneAchievements = async () => {
  await delay(200);
  const data = await getProgressData();
  return data.stats.milestoneAchievements || [];
};

export const updateMilestoneAchievement = async (days, claimed = true) => {
  await delay(200);
  // In a real app, this would update the backend
  return {
    success: true,
    milestone: {
      days,
      claimed,
      claimedDate: new Date().toISOString()
    }
  };
};

export const checkStreakMilestones = async (currentStreak) => {
  await delay(200);
  const milestones = [7, 14, 30, 60, 100];
  const achievedMilestones = milestones.filter(m => currentStreak >= m);
  const data = await getProgressData();
  const claimedMilestones = data.stats.milestoneAchievements?.map(m => m.days) || [];
  const unclaimedMilestones = achievedMilestones.filter(m => !claimedMilestones.includes(m));
  
  return {
    achieved: achievedMilestones,
    unclaimed: unclaimedMilestones,
    nextMilestone: milestones.find(m => m > currentStreak) || null
  };
};

export const calculateMilestoneRewards = async (days) => {
  await delay(100);
  const rewardMap = {
    7: { xp: 50, gems: 10 },
    14: { xp: 100, gems: 25 },
    30: { xp: 250, gems: 50 },
    60: { xp: 500, gems: 100 },
    100: { xp: 1000, gems: 200 }
  };
  
  return rewardMap[days] || { xp: 0, gems: 0 };
};

export const checkBadgeUnlocks = async (progress, stats) => {
  await delay(200);
  
  try {
    const unlocks = await checkUnlocks(progress, stats);
    return unlocks;
  } catch (err) {
    console.error('Error checking badge unlocks:', err);
    return [];
  }
};

export const getBadgeEligibility = async (progress, stats) => {
  await delay(150);
  
  const eligibility = {
    accuracy: {
      current: progress.reduce((sum, p) => sum + p.accuracy, 0) / (progress.length || 1),
      milestones: [80, 85, 90, 95, 100]
    },
    crowns: {
      current: stats.totalCrowns,
      milestones: [1, 5, 10, 15, 20]
    },
    streak: {
      current: stats.currentStreak,
      milestones: [7, 14, 30, 60, 100]
    },
    xp: {
      current: stats.totalXP,
      milestones: [50, 300, 500, 1000, 5000]
    }
  };
  
  return eligibility;
};